// content/openwhen.ts
// Surat "Buka saat...". lockUntilISO (YYYY-MM-DD, WIB) opsional: amplop terkunci sampai tanggal itu.
export interface OpenWhen {
  id: string;
  title: string;
  text: string;
  lockUntilISO?: string;
}

export const openWhen: OpenWhen[] = [
  { id: "rindu", title: "saat kamu rindu", text: "TODO: surat untuk saat dia rindu" },
  { id: "sedih", title: "saat kamu sedih", text: "TODO: surat untuk saat dia sedih" },
  { id: "susah-tidur", title: "saat kamu tidak bisa tidur", text: "TODO: surat untuk saat dia susah tidur" },
  { id: "tahun-depan", title: "saat ulang tahun berikutnya", text: "TODO: surat untuk ulang tahun berikutnya", lockUntilISO: "TODO: YYYY-MM-DD" },
];
